import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import './screens/edit_categories_screen.dart';
import './providers/categories.dart';
import './screens/category_screen.dart';
import './screens/categories_overview_screen.dart';
import './screens/add_item_screen.dart';

void main(List<String> args) {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => Categories(),
        )
      ],
      child: MaterialApp(
        title: 'Save All Me',
        theme: ThemeData(primarySwatch: Colors.purple),
        home: SafeArea(child: CategoriesOverviewScreen()),
        routes: {
          AddItemScreen.routeName: (context) => AddItemScreen(),
          CategoryScreen.routeName:(context)=>CategoryScreen(),
          EditCategoriesScreen.routeName:(context)=>EditCategoriesScreen(),
        },
      ),
    );
  }
}
