#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/media/yase/3a3893b7-ad3a-4c21-a1b1-b1cc0d02a917/yase/Programming/Flutter/flutter"
export "FLUTTER_APPLICATION_PATH=/media/yase/3a3893b7-ad3a-4c21-a1b1-b1cc0d02a917/yase/Programming/Flutter/projects/save_all_me"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "FLUTTER_FRAMEWORK_DIR=/media/yase/3a3893b7-ad3a-4c21-a1b1-b1cc0d02a917/yase/Programming/Flutter/flutter/bin/cache/artifacts/engine/ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
